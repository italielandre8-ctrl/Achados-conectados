# Achados e Conectados

Site escolar para registrar objetos encontrados, permitir que a direção aprove publicações e receber solicitações privadas de alunos.

## Importante antes de publicar

O site tem dois modos:
- **Modo de demonstração:** sem configurar Firebase, os dados ficam apenas no navegador/dispositivo atual. Não serve para uso real entre aluno e direção.
- **Modo conectado:** depois de configurar o Firebase, fotos e registros podem ser compartilhados entre dispositivos. O login da direção usa Firebase Authentication.

## Arquivos
- `index.html` — estrutura das páginas
- `style.css` — aparência responsiva para celular e computador
- `app.js` — funcionalidades e conexão com Firebase

## Configurar Firebase para sincronizar os dispositivos

1. Entre em https://console.firebase.google.com/ com uma conta Google autorizada pela escola.
2. Crie um projeto, por exemplo `achados-e-conectados`.
3. Adicione um aplicativo Web e copie a configuração Firebase.
4. No `app.js`, substitua os valores `COLOQUE_...` dentro de `firebaseConfig` pelos valores do projeto.
5. Em **Authentication > Sign-in method**, habilite **E-mail/senha**.
6. Em **Authentication > Users**, crie o usuário da direção com e-mail e senha fortes. Não compartilhe a senha com alunos.
7. Crie o banco **Firestore Database**.
8. Ative **Storage** para armazenar as fotos.
9. Configure as regras de Firestore e Storage abaixo.
10. Publique os três arquivos no GitHub Pages. Para testar módulos Firebase, abra o site por HTTPS.

## Regras iniciais de Firestore

Estas regras permitem que visitantes enviem objetos e reclamações, mas somente usuários autenticados leem os envios privados e reclamações. O mural publicado pode ser lido por qualquer pessoa. Para uso real em escola, peça a um adulto responsável/técnico para revisar e endurecer as regras contra spam e abuso antes de divulgar o site.

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isDirector() {
      return request.auth != null;
    }

    match /submissions/{id} {
      allow create: if request.resource.data.keys().hasAll(['description','place','imageUrl','status','createdAt'])
                    && request.resource.data.status == 'pending';
      allow read, update, delete: if isDirector();
    }

    match /items/{id} {
      allow read: if true;
      allow create, update, delete: if isDirector();
    }

    match /claims/{id} {
      allow create: if request.resource.data.keys().hasAll(['itemId','studentName','proof','status','createdAt'])
                    && request.resource.data.status == 'new';
      allow read, update, delete: if isDirector();
    }
  }
}
```

**Nota de segurança:** essa regra de exemplo considera qualquer usuário autenticado como diretor. Em produção, restrinja o acesso por UID/e-mail autorizado ou por custom claims e faça revisão das regras antes de usar com dados reais.

## Regras iniciais do Storage

```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /objects/{fileName} {
      allow read: if true;
      allow write: if request.resource != null
                   && request.resource.size < 5 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*');
      allow delete: if request.auth != null;
    }
  }
}
```

Essas regras são um ponto de partida, não uma configuração de segurança perfeita. Como qualquer pessoa pode enviar fotos sem login, monitore o uso e adicione proteção contra spam. Evite fotografar rostos, documentos, dados pessoais ou informações sensíveis.

## Como usar

### Aluno
1. Escolhe **Sou aluno**.
2. Envia foto, descrição e local onde encontrou o objeto.
3. Abre **Procurar objeto** para ver itens que a direção já publicou.
4. Clica em **Este é meu** e envia nome + detalhe privado para a direção.

### Direção
1. Escolhe **Sou diretor** e entra com a conta criada no Firebase.
2. Analisa os envios recebidos.
3. Clica em **Publicar** para colocar um objeto no mural ou **Recusar** para removê-lo.
4. Abre **Reclamações** para conferir as informações privadas e marcar solicitações como analisadas.
5. Remove do mural um objeto que já foi devolvido.

## Sobre notificações
Nesta versão, as novas reclamações aparecem no painel e o contador é atualizado quando o painel é carregado. Notificação push/e-mail automática requer configuração adicional (por exemplo, Cloud Functions e um serviço de envio). O site não envia notificações push automaticamente ainda.

## Teste local
Como `app.js` usa módulos JavaScript, rode por um servidor local ou publique em HTTPS. Abrir o arquivo `index.html` diretamente pode impedir a execução do módulo.
